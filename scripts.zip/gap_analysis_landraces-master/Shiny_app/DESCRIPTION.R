Title: My App
Author: Alice Smith
DisplayMode: Showcase
Type: Shiny